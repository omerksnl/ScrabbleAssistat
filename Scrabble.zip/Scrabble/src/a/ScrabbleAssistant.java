package a;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class ScrabbleAssistant {
    private static final Map<Character, Integer> letterValues = new HashMap<>();

    static {
        letterValues.put('A', 1);
        letterValues.put('E', 1);
        letterValues.put('I', 1);
        letterValues.put('O', 1);
        letterValues.put('U', 1);
        letterValues.put('L', 1);
        letterValues.put('N', 1);
        letterValues.put('S', 1);
        letterValues.put('T', 1);
        letterValues.put('R', 1);

        letterValues.put('D', 2);
        letterValues.put('G', 2);

        letterValues.put('B', 3);
        letterValues.put('C', 3);
        letterValues.put('M', 3);
        letterValues.put('P', 3);

        letterValues.put('F', 4);
        letterValues.put('H', 4);
        letterValues.put('V', 4);
        letterValues.put('W', 4);
        letterValues.put('Y', 4);

        letterValues.put('K', 5);

        letterValues.put('J', 8);
        letterValues.put('X', 8);

        letterValues.put('Q', 10);
        letterValues.put('Z', 10);
    }

    public static void main(String[] args) {
        Set<String> dictionary = loadDictionary("./src/dictionary.txt");

        if (dictionary.isEmpty()) {
            System.out.println("Dictionary is empty or file not found. Exiting...");
            return;
        }

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter your hand. At most seven tiles, use _ for blank tiles.");
        String hand = scanner.nextLine().toUpperCase();

        for (int i = 0; i < hand.length(); i++) {
            char currentChar = hand.charAt(i);

            if (!(currentChar >= 'A' && currentChar <= 'Z') && currentChar != '_') {
                System.out.println("Invalid character in the input. Please enter valid tiles.");
                return;
            }
        }

        if (hand.length() <= 7) {
            System.out.println("Continue with other operations...");

            System.out.println("Enter the pattern to match. Use * for tiles you will place.");
            String pattern = scanner.nextLine().toUpperCase();

            List<WordScore> matchingWords = findMatchingWords(hand, pattern, dictionary);

            if (matchingWords.isEmpty()) {
                System.out.println("No matching words found.");
            } else {
                System.out.println("------");
                for (WordScore wordScore : matchingWords) {
                    System.out.println(wordScore.getScore() + " : " + wordScore.getWord());
                }
            }
        } else {
            System.out.println("Invalid tile input. Use at most seven tiles, and use _ for blank tiles.");
        }
    }

    public static Set<String> loadDictionary(String fileName) {
        Set<String> dictionary = new HashSet<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                dictionary.add(line.trim().toUpperCase());
            }
        } catch (IOException e) {
            System.err.println("File reading error: " + e.getMessage());
        }

        return dictionary;
    }

    public static List<WordScore> findMatchingWords(String hand, String pattern, Set<String> dictionary) {
        List<WordScore> matchingWords = new ArrayList<>();

        for (String dictWord : dictionary) {
            if (canBuildWord(hand, pattern, dictWord) && containsOnlyProvidedLetters(hand, dictWord)) {
                matchingWords.add(new WordScore(dictWord, calculateScore(dictWord)));
            }
        }

        matchingWords.sort(Comparator.comparingInt(WordScore::getScore).reversed());

        return matchingWords;
    }

    public static boolean containsOnlyProvidedLetters(String hand, String word) {
        Set<Character> handLetters = new HashSet<>();
        for (char letter : hand.toCharArray()) {
            if (letter != '_') {
                handLetters.add(letter);
            }
        }

        for (char letter : word.toCharArray()) {
            if (!handLetters.contains(letter)) {
                return false;
            }
        }

        return true;
    }

    public static boolean canBuildWord(String hand, String pattern, String word) {
        if (pattern.length() != word.length()) {
            return false;
        }

        for (int i = 0; i < pattern.length(); i++) {
            char patternChar = pattern.charAt(i);
            char handChar = hand.charAt(i);
            char wordChar = word.charAt(i);

            if (patternChar == '*') {
                if (handChar != '_' && hand.indexOf(wordChar) == -1) {
                    return false;
                }
            } else if (patternChar != wordChar) {
                return false;
            }
        }

        return true;
    }

    public static int calculateScore(String word) {
        int score = 0;

        for (char letter : word.toCharArray()) {
            score += letterValues.getOrDefault(letter, 0);
        }

        return score;
    }

    static class WordScore {
        private final String word;
        private final int score;

        public WordScore(String word, int score) {
            this.word = word;
            this.score = score;
        }

        public String getWord() {
            return word;
        }

        public int getScore() {
            return score;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            WordScore wordScore = (WordScore) o;
            return Objects.equals(word, wordScore.word);
        }

        @Override
        public int hashCode() {
            return Objects.hash(word);
        }
    }
}