package tr.edu.ozyegin.cs101.scrabble;
import java.util.List;
import java.util.ArrayList;

public class Scorer {
    public static int calculateScore(String word, String tiles, String pattern) {
        int score = 0;
        word = word.toUpperCase();
        List<Integer> scoredIndexes = new ArrayList<Integer>();
        List<Character> charList = new ArrayList<>(tiles.chars().mapToObj(c -> (char) c).toList());

        for (int i = 0; i < pattern.length(); i++) {
            if (pattern.charAt(i) != '*') {
                score += WordPoints.valueForLetter(pattern.charAt(i));
                scoredIndexes.add(i);
            }
        }
        for (int i = 0; i < word.length(); i++) {
            if (charList.contains(word.charAt(i)) && !scoredIndexes.contains(i)) {
                score += WordPoints.valueForLetter(word.charAt(i));
                charList.remove(Character.valueOf(word.charAt(i)));
            }
        }

        return score;
    }
}
