package tr.edu.ozyegin.cs101.scrabble;
import java.util.Scanner;
import java.util.List;

public class ScrabbleAssistant {

    public static void main(String[] args) {
        String desktopPath = "./src/dictionary.txt";
        List<String> dictionary = WordReader.readWordsFromFile(desktopPath);

        Scanner scanner = new Scanner(System.in);

        while (true) {
            String tilesInHand, pattern;
            while (true) {
                System.out.print("Enter your hand. At most seven tiles, use _ for blank tiles: ");
                tilesInHand = scanner.nextLine().toUpperCase();

                if (tilesInHand.length() <= 7 && tilesInHand.matches("[A-Z_]+")) {
                    break;
                } else {
                    System.out.println("Invalid input. You must enter at most seven tiles and only english characters and _.");
                }
            }

            while (true) {
                System.out.print("Enter the pattern to match. Use * for tiles you will place: ");
                pattern = scanner.nextLine().toUpperCase();
                if (pattern.matches("[A-Z*]+")) {
                    break;
                } else {
                    System.out.println("Invalid input. You must enter only english characters and *.");
                }
            }

            List<String> matchingWords = WordMatcher.findMatchingWords(tilesInHand, pattern, dictionary);

            if (matchingWords.isEmpty()) {
                System.out.println("No matching words found with the given tiles and pattern.");
            } else {
                String finalTilesInHand = tilesInHand;
                String finalPattern = pattern;
                matchingWords.sort((w1, w2) -> Scorer.calculateScore(w2, finalTilesInHand, finalPattern) - Scorer.calculateScore(w1, finalTilesInHand, finalPattern));
                for (String word : matchingWords) {
                    System.out.println(Scorer.calculateScore(word, tilesInHand, pattern) + " : " + word);
                }
            }
            System.out.print("Do you want to play another round? (yes/no): ");
            String response = scanner.nextLine().trim().toLowerCase();
            if (!response.equals("yes")) {
                break;
            }
        }
        scanner.close();
    }
}

