package tr.edu.ozyegin.cs101.scrabble;
import java.lang.IllegalArgumentException;
public class WordPoints {
    public static int valueForLetter(char c) throws IllegalArgumentException{
        switch (c) {
            case 'A', 'E', 'I', 'O', 'U', 'L', 'N', 'S', 'T', 'R' ->{return 1;}
            case 'D', 'G' -> {return 2;}
            case 'B', 'C', 'M', 'P' -> {return 3;}
            case 'F', 'H', 'V', 'W', 'Y' -> {return 4;}
            case 'K' -> {return 5;}
            case 'J', 'X' -> {return 8;}
            case 'Q', 'Z' -> {return 10;}
            case '_', '*' -> {return 0;}
            default -> throw new IllegalArgumentException ("Invalid input -> " + c);
        }

    }
}