package tr.edu.ozyegin.cs101.scrabble;
import java.util.ArrayList;
import java.util.List;
public class WordMatcher {

    public static List<String> findMatchingWords(String tilesInHand, String pattern, List<String> dictionary) {
        List<String> matchingWords = new ArrayList<>();

        for (String word : dictionary) {
            if (word.length() == pattern.length() && wordThatFitsPattern(tilesInHand, word, pattern)) {
                matchingWords.add(word);
            }
        }
        return matchingWords;
    }

    private static boolean wordThatFitsPattern(String tilesInHand, String word, String pattern) {
        StringBuilder availableTiles = new StringBuilder(tilesInHand);

        for (int i = 0; i < pattern.length(); i++) {
            char patternChar = pattern.charAt(i);
            char wordChar = word.charAt(i);

            if (patternChar != '*' && patternChar != wordChar) {
                return false;
            }

            if (patternChar == '*' || availableTiles.indexOf("_") != -1) {
                int tileIndex = availableTiles.indexOf(String.valueOf(wordChar));
                int jokerIndex = availableTiles.indexOf("_");

                if (tileIndex == -1 && jokerIndex == -1) {
                    return false;
                } else if (tileIndex != -1) {
                    availableTiles.deleteCharAt(tileIndex);
                } else {
                    availableTiles.deleteCharAt(jokerIndex);
                }
            }
        }
        return true;
    }
}
