package tr.edu.ozyegin.cs101.scrabble;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class WordReader {

    public static List<String> readWordsFromFile(String filename) {
        try (Stream<String> stream = Files.lines(Paths.get(filename))) {
            return stream
                    .map(String::toUpperCase)
                    .collect(Collectors.toList());
        } catch (IOException e) {
            throw new IllegalArgumentException("The file " + filename + " could not be opened for reading.");
        }
    }
}
